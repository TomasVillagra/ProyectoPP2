
from django.contrib import admin
from django.urls import path, include
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

urlpatterns = [
    path("admin/", admin.site.urls),
    path("pizzeria/", include("pizzeria.urls")),          # ya tienes /pizzeria/ping/
    path("api/", include("pizzeria.api.urls")),           # ← NUEVO: expone /api/...
    path("api/auth/token/", TokenObtainPairView.as_view(), name="token_obtain_pair"),
    path("api/auth/refresh/", TokenRefreshView.as_view(), name="token_refresh"),
    path("api/auth/", include("authapp.urls")),    
]
